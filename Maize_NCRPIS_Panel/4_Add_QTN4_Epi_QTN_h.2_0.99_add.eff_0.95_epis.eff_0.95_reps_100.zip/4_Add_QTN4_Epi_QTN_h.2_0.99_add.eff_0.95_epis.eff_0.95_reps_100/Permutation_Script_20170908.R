setwd("/Users/adminuser/Box Sync/Lipka_Mainzer_Chen_Epistasis_Shared_Folder/Simulation_Study/NCRPIS_aka_Ames/4_Add_QTN4_Epi_QTN_h.2_0.99_add.eff_0.95_epis.eff_0.95_reps_100/")
library(permute)

prefix.file.name <- "Simulated.Data.100.Reps.Herit.0.99n="
n.perms <- 100
pheno.data.2648  <- read.table(file = paste(prefix.file.name,"2648.txt", sep = ""), sep = "\t", header = TRUE, stringsAsFactors = FALSE,na.strings = ".")
pheno.data.2648 <- pheno.data.2648[,1:2]

pheno.data.1000 <- read.table(file = paste(prefix.file.name,"1000.txt", sep = ""), sep = "\t", header = TRUE, stringsAsFactors = FALSE,na.strings = ".") 
pheno.data.1000 <- pheno.data.1000[,1:2]

pheno.data.300<- read.table(file = paste(prefix.file.name,"300.txt", sep = ""), sep = "\t", header = TRUE, stringsAsFactors = FALSE,na.strings = ".") 
pheno.data.300 <- pheno.data.300[,1:2]



#test of how permutations work
#test.data <- data.frame(Pop = c(rep("A", 10), rep("B",10), rep("C",10)), val = 101:130)

#CNTRL <- permControl(strata = test.data$Pop)
#x <- shuffle(nrow(test.data),control = CNTRL)
#x <- shuffleSet(nrow(test.data),nset = 10, control = CNTRL)


#the vectors come from the rows. 
#test.data$val[x[1,]]

#pheno.data <- pheno.data[order(pheno.data$pop),]  #make sure that the frame is in order

x.2648 <- shuffleSet(nrow(pheno.data.2648),nset = n.perms)  
x.1000 <- shuffleSet(nrow(pheno.data.1000),nset = n.perms) 
x.300 <- shuffleSet(nrow(pheno.data.300),nset = n.perms)

#setwd(paste("Z:\\August_2010_Data\\Tocos_NAM_2009_2010\\Joint_Linkage_Analysis\\Permuted_", BLUP.or.BLUE, "s", sep = ""))

#create 1000 permutations based on populations - done on another computer
#load("Fullpermute.RData")
#curr.dir <- getwd()
perm.set.2648 <- as.matrix(pheno.data.2648[,1])
perm.set.1000 <- as.matrix(pheno.data.1000[,1])
perm.set.300 <- as.matrix(pheno.data.300[,1])

for(j in 1:n.perms){ #loop for each permutation
  perm.set.2648 <- cbind(perm.set.2648,pheno.data.2648[x.2648[j,],2])
  perm.set.1000 <- cbind(perm.set.1000,pheno.data.1000[x.1000[j,],2])
  perm.set.300 <- cbind(perm.set.300,pheno.data.300[x.300[j,],2])
} #end for(j in 1:1000)

perm.set.2648 <- data.frame(perm.set.2648)
colnames(perm.set.2648)[1] <- "<Trait>"
write.table(perm.set.2648, file = "PermDatan.n=2648.txt",sep = "\t", row.names = FALSE,quote = FALSE)

perm.set.1000 <- data.frame(perm.set.1000)
colnames(perm.set.1000)[1] <- "<Trait>"
write.table(perm.set.1000, file = "PermDatan.n=1000.txt",sep = "\t", row.names = FALSE,quote = FALSE)

perm.set.300 <- data.frame(perm.set.300)
colnames(perm.set.300)[1] <- "<Trait>"
write.table(perm.set.300, file = "PermDatan.n=300.txt",sep = "\t", row.names = FALSE,quote = FALSE)

#setwd(curr.dir)

#confirm Works!
#check1 <- aggregate(pheno.data[[i]], list(pheno.data$pop), mean, na.rm = T)
#check2 <- aggregate(perm.set$V5, list(perm.set$pop), mean, na.rm = T)
# all.equal(check1,check2)

